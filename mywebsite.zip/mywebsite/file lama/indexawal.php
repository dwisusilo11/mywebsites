<!DOCTYPE html>
<html>
<body>
<?php
echo "<h1>Halo dari localhost e mas susi!</h1>";
?>
</body>
</html>